import hpvsim as hpv

sim = hpv.Sim().run()
sim.plot()